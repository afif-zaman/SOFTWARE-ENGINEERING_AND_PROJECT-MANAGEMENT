import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.LinkedHashMap;
import java.util.Map;

public class Container {
    private final Map<String, Object> beans = new LinkedHashMap<>();

    public void scan(Class<?>... classes) {
        for (Class<?> type : classes) {
            Component component = type.getAnnotation(Component.class);
            if (component == null) {
                System.out.println("[Container] Skipped: " + type.getSimpleName() + " (no @Component)");
                continue;
            }
            String name = component.value();
            if (name.isEmpty()) {
                String simple = type.getSimpleName();
                name = Character.toLowerCase(simple.charAt(0)) + simple.substring(1);
            }
            if (beans.containsKey(name)) {
                throw new IllegalStateException("Duplicate bean name: " + name);
            }
            try {
                Constructor<?> constructor = type.getDeclaredConstructor();
                constructor.setAccessible(true);
                Object bean = constructor.newInstance();
                beans.put(name, bean);
                System.out.println("[Container] Registered: " + name + " (" + type.getSimpleName() + ")");
            } catch (ReflectiveOperationException e) {
                throw new IllegalStateException("Cannot instantiate " + type.getName(), e);
            }
        }
    }

    public void injectValues(Map<String, String> config) {
        for (Object bean : beans.values()) {
            for (Field field : bean.getClass().getDeclaredFields()) {
                Value annotation = field.getAnnotation(Value.class);
                if (annotation == null) continue;
                String key = annotation.value();
                if (!config.containsKey(key)) {
                    throw new IllegalArgumentException("Missing config key: " + key);
                }
                String raw = config.get(key);
                Object converted;
                if (field.getType() == String.class) converted = raw;
                else if (field.getType() == int.class) converted = Integer.parseInt(raw);
                else throw new IllegalArgumentException("Unsupported @Value field type: " + field.getType());
                try {
                    field.setAccessible(true);
                    field.set(bean, converted);
                    System.out.println("[Container] Injected: " + key + " -> " + bean.getClass().getSimpleName() + "." + field.getName());
                } catch (IllegalAccessException e) {
                    throw new IllegalStateException("Cannot inject " + field.getName(), e);
                }
            }
        }
    }

    public Object getBean(String name) {
        return beans.get(name);
    }

    public Iterable<Object> getBeans() {
        return beans.values();
    }
}
