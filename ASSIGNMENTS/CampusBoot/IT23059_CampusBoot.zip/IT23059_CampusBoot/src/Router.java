import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Router {
    public static String dispatch(Container c, String path) {
        for (Object bean : c.getBeans()) {
            for (Method method : bean.getClass().getDeclaredMethods()) {
                Route route = method.getAnnotation(Route.class);
                if (route == null) continue;
                String mappedPath = route.path().isEmpty() ? route.value() : route.path();
                if (!mappedPath.equals(path)) continue;
                try {
                    method.setAccessible(true);
                    return (String) method.invoke(bean);
                } catch (ReflectiveOperationException e) {
                    throw new IllegalStateException("Failed to dispatch " + path, e);
                }
            }
        }
        return "404 Not Found: " + path;
    }
}
