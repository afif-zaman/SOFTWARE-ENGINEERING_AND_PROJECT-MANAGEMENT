# CampusBoot — Java Reflection and Custom Annotations

A plain-Java 11+ mini-framework. No Spring Boot, Maven, or third-party dependencies are needed.

## Run in IntelliJ IDEA
1. Open the `CampusBoot` folder as a Java project.
2. Set Project SDK to Java 11 or newer.
3. Mark `src` as Sources Root if IntelliJ does not recognize it automatically.
4. Open `src/Main.java` and click the green Run button next to `main`.

## Run in terminal
From the CampusBoot directory:

```powershell
javac -d out src/*.java
java -cp out Main
```

## Architecture
- `@Component`: marks classes for registration in `Container`.
- `@Value`: injects configuration strings and ints.
- `@Range`: validates integer fields.
- `@Route`: maps a path to a no-argument String-returning method.

`GradeController.java`, `ReportPrinter.java`, `Student.java`, and `Main.java` reproduce the assignment starter logic.

Review the reflection implementation and adapt the explanatory answers to your own understanding before submitting.

## Starter/spec discrepancy
The assignment specifies `@Route(path="/hello")` via a `path()` element, but the unchanged starter uses `@Route("/hello")`, which requires a `value()` element. Java cannot compile the unchanged starter with only `path()` on the annotation. To keep the starter unchanged and compilable, `Route` provides both `path()` and `value()` with empty-string defaults; `Router` accepts either. Ask the instructor whether this compatibility extension is acceptable if the annotation declaration must be exactly as specified.
